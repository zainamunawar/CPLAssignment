//A university takes a student's percentage, entry-test marks out of 100, and interview score out of 10.
//Write a C++ program that first checks whether all inputs are valid. Students with a percentage below 60 or an entry-test score below 50 are not eligible.
//If eligible, check whether the interview score is at least 6. Students with a percentage of 90 or above, entry-test marks of at least 80, and an interview score of
//at least 8 receive a "Full Scholarship". Students with a percentage of at least 80, entry-test marks of at least 70, and an interview score of at least 7 
//receive a "Half Scholarship". 
//Other eligible students receive "Admission Granted".
#include<iostream>
using namespace std;
int main()
{ 
float percentage;
int test;
int interview;
cout<<"percen="<<endl;
cin>>percentage;
cout<<"marks="<<endl;
cin>>test;
cout<<"interview score="<<endl;
cin>>interview;
if(percentage >= 0 && percentage <= 100 &&
   test >= 0 && test <= 100 &&
   interview >= 0 && interview <= 10)
{
    cout<<"All inputs are valid"<<endl;
}
else
{
    cout<<"Invalid Input";
}
if(percentage < 60 || test < 50)
{
    cout<<"Not Eligible";
}
else
{
    if(interview < 6)
    {
        cout<<"Not Eligible";
    }
    
    else
    {
        if(percentage >= 90 && test >= 80 && interview >= 8)
        {
            cout<<"Full Scholarship";
        }
        else if(percentage >= 80 && test >= 70 && interview >= 7)
        {
            cout<<"Half Scholarship";
        }
        else
        {
            cout<<"Admission Granted";
        }
    }
}

}