
#include<iostream>
using namespace std;

int main()
{
    int units;
    int type;
    int price;
    int bill;
    int tax;
    int final_bill;

    cout<<"Enter units consumed="<<endl;
    cin>>units;

    cout<<"Enter customer type (1 Domestic, 2 Commercial)="<<endl;
    cin>>type;

    if(units<=0)
    {
        cout<<"Invalid units";
    }
    else if(type!=1 && type!=2)
    {
        cout<<"Invalid customer type";
    }
    else
    {
        if(units<=100)
        {
            price=10;
        }
        else if(units<=300)
        {
            price=15;
        }
        else
        {
            price=20;
        }

        bill=units*price;

        if(type==2)
        {
            tax=bill*10/100;
        }
        else
        {
            tax=0;
        }

        final_bill=bill+tax;

        cout<<"Original bill="<<bill<<endl;
        cout<<"Tax="<<tax<<endl;
        cout<<"Final bill="<<final_bill<<endl;
    }

    return 0;
}
