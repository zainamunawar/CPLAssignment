//Write a C++ program that displays a menu with three categories: 1. Electronics, 2. Clothing, and 3. Books.
//Take the user's choice, product price, quantity, and membership status (true or false) as input. If the user selects Electronics, 
//give a 15% discount if they are a member and the total purchase is at least Rs. 20,000; otherwise, give a 5% discount if the total is at least Rs. 30,000.
//If the user selects Clothing, give a 20% discount for members and 10% for non-members when the total is at least Rs. 5,000. If the user selects Books,
//give a 10% discount when the total is at least Rs. 2,000, regardless of membership. Display the original bill, discount amount, and final bill.
//If the choice or any input is invalid, display an appropriate error message.
#include<iostream>
using namespace std;
int main()
{
	cout<<"======================================================================================================"<<endl;
	cout<<"menu\n1-ELECTRONICS\n2-CLOTHING\n3-BOOKS"<<endl;
	cout<<"======================================================================================================="<<endl;
  int choice,price,quantity;
  bool status;
  int total_purchase;
  int discount;
  cout<<"enter choice";
  cin>>choice;
  cout<<"\nenter price=";
  cin>>price;
  cout<<"\nstatus=";
  cin>>status;
  cout<<"quantity=";
  cin>>quantity;
  if(choice==1)
  {
  	if(total_purchase<=20000&&status==true)
  	{
  	total_purchase=price*quantity;
  	cout<<"15% discount and if they're a member and total bill is of 20,000"<<total_purchase<<endl;
  	discount=total_purchase*15/100;
  	cout<<"after 15 percent discount"<<discount<<endl;
  }
  else
  {
  	  total_purchase=price*quantity;
  cout<<"5% discount if the total bill is of 30,000"<<total_purchase<<endl;
  discount=total_purchase*5/100;
  cout<<"after discount"<<discount<<endl;
  }
}
  if(choice==2)
  {
  	if(total_purchase==5000&&status==true)
  	{
  		  	total_purchase=price*quantity;
   cout<<"20% discount for members when the bill is of 5000"<<total_purchase<<endl;
   discount=total_purchase*20/100;
  	cout<<"after discount"<<discount<<endl;
    }
  else 
  {
  	  total_purchase=price*quantity;
  cout<<"10% for non members when the bill is of 5000"<<total_purchase<<endl;
  discount=total_purchase*10/100;
  cout<<"after discount"<<discount<<endl;
}
}
if(choice==3)
{
	if(total_purchase==2000)
	{
			total_purchase=price*quantity;
	cout<<"10% discount when the total is at least Rs. 2,000 regardless of membership"<<total_purchase<<endl;
	discount= total_purchase
	*10/100;
	cout<<"after discount="<<discount<<endl;
}
else
cout<<"invalid choice entered by the user";
}
}