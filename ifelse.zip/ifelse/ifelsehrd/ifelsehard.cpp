//Write a C++ program that takes a passenger's age, ticket status (Y or N), and security clearance status (Y or N).
//If the passenger is under 12, they must be accompanied by an adult; otherwise, display "Adult Required". If the passenger is 12 or older, 
//check whether they have a valid ticket. If they do, check their security clearance. Display "Boarding Allowed"
//only if all required conditions are satisfied; otherwise, display the appropriate message.
#include<iostream>
using namespace std;
int main()
{
	int age;
	char status;
	char clearence;
	cout<<"age:";
	cin>>age;
	cout<<"ticket status=";
	cin>>status;
	cout<<"security clearence=";
	cin>>clearence;
	if(age<12)
{	
	cout<<"must be accompanied by an adult"<<endl;
}
else
{
	if(age>=12)
	{

		if(status=='Y'&&clearence=='Y')
		{
			cout<<"boarding allowed";
		}
	else
	cout<<"boarding isnt allowed";
	}
	
}
}