#include<iostream>
using namespace std;
int main()
{
	int choice;
	int price;
	int total_bill;
	int quantity;
	int discount;
	bool status;
	cout<<"(1. Pizza, 2. Burger, 3. Pasta)"<<endl;
	cout<<"choice="<<endl;
	cin>>choice;
	cout<<"qunatity="<<endl;
	cin>>quantity;
	cout<<"status="<<endl;
	cin>>status;
	cout<<"price="<<endl;
	cin>>price;
	if(choice==1||choice==2||choice==3)
	{
		if(status==true && total_bill==3000)
		{
		cout<<"if the total bill is of rs 3000 then members will get 15% discount"<<endl;
		total_bill=quantity*price;
		cout<<"total bill="<<total_bill<<endl;
		discount=total_bill*15/100;
	}
	else
	{
	cout<<"non-members will get 5%"<<endl;
	total_bill=quantity*price;
	cout<<"total bill="<<total_bill<<endl;
	discount=total_bill*5/100;
	cout<<"discount="<<discount<<endl;
        }
    }
else
cout<<"invalid quantity or invalid choices";
}