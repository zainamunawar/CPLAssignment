#include<iostream>
using namespace std;
int main()
{
    int a,b;
    char op;

    cout<<"num1=";
    cin>>a;

    cout<<"num2=";
    cin>>b;

    cout<<"operator=";
    cin>>op;

    if(op=='+' || op=='-' || op=='*' || op=='/')
    {
        if(op=='+')
        {
            cout<<"num1+num2="<<a+b<<endl;
        }

        if(op=='-')
        {
            cout<<"num1-num2="<<a-b<<endl;
        }

        if(op=='*')
        {
            cout<<"num1*num2="<<a*b<<endl;
        }

        if(op=='/')
        {
            cout<<"num1/num2="<<a/b<<endl;
        }
    }
    else
    {
        cout<<"invalid op";
    }
}