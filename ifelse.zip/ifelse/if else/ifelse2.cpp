//2. Shopping Discount
//Take shopping amount:
//If amount = 5000 ? 10% discount
//Otherwise ? no discount
#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"Amount=";
	cin>>a;
	if(a>=5000)
	cout<<"10% discount";
	else
	cout<<"no 10% discount";
}