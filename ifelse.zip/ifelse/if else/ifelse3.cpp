//Employee Working Days
//Take number of working days:
//25–30 → Full-time employee
//Otherwise → Part-time employee
#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"number of working days=";
	cin>>a;
	if(a>=25 && a<=30)
	cout<<"FULL-TIME EMPLOYEE";
	else
	cout<<"PART-TIME EMPLOYEE";
}