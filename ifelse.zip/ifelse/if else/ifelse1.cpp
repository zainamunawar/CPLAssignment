//1. Temperature
//Take temperature and print:
//Hot if temperature = 30
//Cold otherwise
#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"temperature=";
	cin>>a;
	if(a>=30)
	cout<<"hot";
	else
	cout<<"cold";
}