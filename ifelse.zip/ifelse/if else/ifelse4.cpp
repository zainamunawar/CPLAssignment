//Login System
//Take a username and password:
//If both are correct ? Login successful
//Otherwise ? Invalid username or password
#include<iostream>
#include<string>
using namespace std;
int main()
{
	string a;
	string b;
	cout<<"username=";
	cin>>a;
	cout<<"password=";
	cin>>b;
	string c="laveeza";
	string d="03-134262-056";
	if(a==c&&b==d)
	cout<<"login succesfull";
	else
	cout<<"inavlid username or password";
	
}