
#include<iostream>
using namespace std;
int main()
{
    int age;
    cout<<"enter age="<<endl;
    cin>>age;

    char test;
    cout<<"test status="<<endl;
    cin>>test;

    char clearance;
    cout<<"enter Y/N="<<endl;
    cin>>clearance;

    if(age>=18)
    {
        if(test=='P')
        {
            if(clearance=='Y')
            {
                cout<<"license approved"<<endl;
            }
            else
            {
                cout<<"medical clearance required"<<endl;
            }
        }
        else
        {
            cout<<"failed driving test"<<endl;
        }
    }
    else
    {
        cout<<"license not approved";
    }
}