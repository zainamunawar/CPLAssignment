
#include<iostream>
using namespace std;
int main()
{
    int age;
    bool id;
    bool registration;

    cout<<"enter age="<<endl;
    cin>>age;

    cout<<"registration (1=true, 0=false)=";
    cin>>registration;

    cout<<"enter id (1=true, 0=false)="<<endl;
    cin>>id;

    if(age>=18)
    {
        if(id==true)
        {
            if(registration==true)
            {
                cout<<"access granted";
            }
            else
            {
                cout<<"registration required";
            }
        }
        else
        {
            cout<<"invalid id";
        }
    }
    else
    {
        cout<<"access denied";
    }
}