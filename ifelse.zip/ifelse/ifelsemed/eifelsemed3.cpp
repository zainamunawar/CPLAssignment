
#include<iostream>
using namespace std;
int main()
{
    int age;
    cout<<"enter age="<<endl;
    cin>>age;

    int percentage;
    cout<<"enter percentage="<<endl;
    cin>>percentage;

    char exam;
    cout<<"enter exam status="<<endl;
    cin>>exam;

    if(age>=18 && percentage>=75 && exam=='P')
    {
        cout<<"eligible for graduation";
    }
    else
    {
        if(age>=18 && percentage<75)
        {
            cout<<"low attendance";
        }
        else
        {
            if(percentage>=75 && exam=='F')
            {
                cout<<"failed exam";
            }
            else
            {
                cout<<"not eligible";
            }
        }
    }
}