#include<iostream>
using namespace std;
int main()
{
    int balance, amount;

    cout<<"Enter account balance=";
    cin>>balance;

    cout<<"Enter withdrawal amount=";
    cin>>amount;

    if(amount>0 && amount<=balance && amount%500==0)
    {
        balance=balance-amount;
        cout<<"Withdrawal successful"<<endl;
        cout<<"Remaining balance="<<balance;
    }
    else
    {
        cout<<"Invalid withdrawal";
    }
}