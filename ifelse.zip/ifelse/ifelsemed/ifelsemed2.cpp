
#include<iostream>
using namespace std;
int main()
{
    int amount;
    float discount, total;

    cout<<"Enter shopping amount=";
    cin>>amount;

    if(amount>=5000)
    {
        discount=amount*0.10;
    }
    else
    {
        discount=amount*0.05;
    }

    total=amount-discount;

    cout<<"Discount="<<discount<<endl;
    cout<<"Final amount="<<total;
}