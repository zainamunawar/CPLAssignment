
#include<iostream>
using namespace std;
int main()
{
	int num1,num2;
	char op;
	int total,diff,product,division;
	cout<<"enter two num="<<endl;
	cin>>num1>>num2;
	cout<<"enter op="<<endl;
	cin>>op;
	switch(op)
	{
		case'+':
		{
	     total=num1+num2;
		 cout<<"total="<<total<<endl; 
		 break;   
		}
		case '-':
			{
			diff=num1-num2;
			cout<<"diff="<<diff<<endl;
			break;
	}
	case '*':
		{
			product=num1*num2;
			cout<<"product"<<product<<endl;
			break;
		}
	case '/':
		{
			division=num1/num2;
			cout<<"division="<<division<<endl;
			break;
		}
}
}