#include<iostream>
using namespace std;

int main()
{
    int choice;

    cout<<"1. Tea"<<endl;
    cout<<"2. Coffee"<<endl;
    cout<<"3. Juice"<<endl;
    cout<<"Enter your choice="<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            cout<<"You selected Tea";
            break;

        case 2:
            cout<<"You selected Coffee";
            break;

        case 3:
            cout<<"You selected Juice";
            break;

        default:
            cout<<"Invalid choice";
    }

    return 0;
}