// Day of the Week
//Write a program that takes a number from 1 to 7 and displays the corresponding day.
//- 1 = Monday
//- 2 = Tuesday
//- 3 = Wednesday
//- 4 = Thursday
//- 5 = Friday
//- 6 = Saturday
//- 7 = Sunday
//If the user enters another number, display "Invalid Day"
#include<iostream>
using namespace std;
int main()
{
	int day;
	cout<<"enter day="<<endl;
	cin>>day;
switch(day)
{

case 1:
	{

		cout<<"MONDAY"<<endl;
		break;	
	}
case 2:
	{

		cout<<"TUESDAY"<<endl;
		break;
	}
case 3:
{

	cout<<"WEDNESDAY"<<endl;
	break;
	}	
case 4:
	{
	
		cout<<"THURSDAY"<<endl;
		break;
	}
case 5:
	{
	
	cout<<"FRIDAY"<<endl;
	break;
	}
case 6:
	{
		
		cout<<"SATURDAY"<<endl;
		break;
	}
case 7:
	{
	
		cout<<"SUNDAY"<<endl;
		break;
	}
		
}
}