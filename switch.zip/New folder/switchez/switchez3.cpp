#include<iostream>
using namespace std;
int main()
{
	int choice,quantity;
	int total_bill;
	int a=1200;
	int b=600;
	int c=450;
	cout<<"users choice="<<endl;
	cin>>choice;
	cout<<"quantity="<<endl;
	cin>>quantity;
	switch(choice)
	{
		case 1:
			{
				cout<<"pizza"<<endl;
				total_bill=quantity*a;
				cout<<"total bill="<<total_bill<<endl;
				break;
			}
		case 2:
			{
				cout<<"burger"<<endl;
				total_bill=quantity*b;
				cout<<"total bill="<<total_bill<<endl;
				break;
			}
		case 3:
			{
			cout<<"sandwich"<<endl;
			total_bill=quantity*c;
			cout<<"total bill="<<total_bill<<endl;
			break;
		}
		default:
		{
			cout<<"invalid choice"<<endl;
		}
	}
}