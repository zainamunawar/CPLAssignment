//Question: Write a C++ program that displays a menu:
//1. Shoes — Rs. 3000
//2. Shirt — Rs. 1500
//3. Bag — Rs. 2000
//4. Exit
//Use switch to select a product. Take the quantity as input and calculate the total bill. If the quantity is 3 or more, 
//give a 10% discount. Display the final bill. For an invalid choice or quantity less than or equal to zero, display an appropriate error message.
#include<iostream>
using namespace std;

int main()
{
    int choice, quantity;
    float price, bill, discount, final_bill;

    cout<<"1. Shoes - Rs. 3000"<<endl;
    cout<<"2. Shirt - Rs. 1500"<<endl;
    cout<<"3. Bag - Rs. 2000"<<endl;
    cout<<"4. Exit"<<endl;

    cout<<"Enter your choice="<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            price=3000;
            break;

        case 2:
            price=1500;
            break;

        case 3:
            price=2000;
            break;

        case 4:
            cout<<"Program ended";
            return 0;

        default:
            cout<<"Invalid choice";
            return 0;
    }

    cout<<"Enter quantity="<<endl;
    cin>>quantity;

    if(quantity<=0)
    {
        cout<<"Invalid quantity";
    }
    else
    {
        bill=price*quantity;

        if(quantity>=3)
        {
            discount=bill*10/100;
        }
        else
        {
            discount=0;
        }

        final_bill=bill-discount;

        cout<<"Total bill="<<bill<<endl;
        cout<<"Discount="<<discount<<endl;
        cout<<"Final bill="<<final_bill;
    }

    return 0;
}