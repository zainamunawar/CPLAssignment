#include<iostream>
using namespace std;

int main()
{
    int choice;
    float side, length, width, radius, area;

    cout<<"1. Square"<<endl;
    cout<<"2. Rectangle"<<endl;
    cout<<"3. Circle"<<endl;

    cout<<"Enter your choice="<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            cout<<"Enter side="<<endl;
            cin>>side;

            area=side*side;
            cout<<"Area of square="<<area;
            break;

        case 2:
            cout<<"Enter length and width="<<endl;
            cin>>length>>width;

            area=length*width;
            cout<<"Area of rectangle="<<area;
            break;

        case 3:
            cout<<"Enter radius="<<endl;
            cin>>radius;

            area=3.14*radius*radius;
            cout<<"Area of circle="<<area;
            break;

        default:
            cout<<"Invalid choice";
    }

    return 0;
}