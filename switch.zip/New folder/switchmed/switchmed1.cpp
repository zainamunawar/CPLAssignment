#include<iostream>
using namespace std;

int main()
{
    int choice, units, price, bill;

    cout<<"1. Domestic"<<endl;
    cout<<"2. Commercial"<<endl;
    cout<<"3. Industrial"<<endl;
    cout<<"4. Exit"<<endl;

    cout<<"Enter customer type="<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            price=10;
            break;

        case 2:
            price=20;
            break;

        case 3:
            price=30;
            break;

        case 4:
            cout<<"Program ended";
            return 0;

        default:
            cout<<"Invalid choice";
            return 0;
    }

    cout<<"Enter units consumed="<<endl;
    cin>>units;

    if(units<=0)
    {
        cout<<"Invalid units";
    }
    else
    {
        bill=units*price;
        cout<<"Total bill="<<bill;
    }

    return 0;
}