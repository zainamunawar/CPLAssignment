#include<iostream>
using namespace std;

int main()
{
    int choice;
    float celsius, fahrenheit;

    cout<<"1. Celsius to Fahrenheit"<<endl;
    cout<<"2. Fahrenheit to Celsius"<<endl;
    cout<<"3. Exit"<<endl;

    cout<<"Enter your choice="<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            cout<<"Enter temperature in Celsius="<<endl;
            cin>>celsius;

            fahrenheit=(celsius*9/5)+32;

            cout<<"Fahrenheit="<<fahrenheit;
            break;

        case 2:
            cout<<"Enter temperature in Fahrenheit="<<endl;
            cin>>fahrenheit;

            celsius=(fahrenheit-32)*5/9;

            cout<<"Celsius="<<celsius;
            break;

        case 3:
            cout<<"Program ended";
            break;

        default:
            cout<<"Invalid choice";
    }

    return 0;
}