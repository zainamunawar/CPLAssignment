#include<iostream>
using namespace std;

int main()
{
    int choice;
    float percentage;

    cout<<"1. Check Grade"<<endl;
    cout<<"2. Check Pass/Fail"<<endl;
    cout<<"3. Check Scholarship"<<endl;
    cout<<"4. Exit"<<endl;

    cout<<"Enter choice="<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            cout<<"Enter percentage="<<endl;
            cin>>percentage;

            if(percentage<0 || percentage>100)
                cout<<"Invalid percentage";
            else if(percentage>=80)
                cout<<"Grade A";
            else if(percentage>=70)
                cout<<"Grade B";
            else if(percentage>=60)
                cout<<"Grade C";
            else if(percentage>=50)
                cout<<"Grade D";
            else
                cout<<"Grade F";
            break;

        case 2:
            cout<<"Enter percentage="<<endl;
            cin>>percentage;

            if(percentage<0 || percentage>100)
                cout<<"Invalid percentage";
            else if(percentage>=50)
                cout<<"Pass";
            else
                cout<<"Fail";
            break;

        case 3:
            cout<<"Enter percentage="<<endl;
            cin>>percentage;

            if(percentage<0 || percentage>100)
                cout<<"Invalid percentage";
            else if(percentage>=90)
                cout<<"Scholarship Granted";
            else
                cout<<"Scholarship Not Granted";
            break;

        case 4:
            cout<<"Program ended";
            break;

        default:
            cout<<"Invalid choice";
    }

    return 0;
}