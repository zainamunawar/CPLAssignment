//1. Electricity Bill with Tax and Discount
//Question: Create a menu with Domestic (Rs. 12/unit), Commercial (Rs. 20/unit), and Industrial (Rs. 30/unit). 
//Take customer type and units as input. If units exceed 200, give a 10% discount. Then add 5% tax to the discounted bill.
#include<iostream>
using namespace std;

int main()
{
    int choice, units, price;
    float bill, discount, tax, final_bill;

    cout<<"1. Domestic"<<endl;
    cout<<"2. Commercial"<<endl;
    cout<<"3. Industrial"<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            price=12;
            break;
        case 2:
            price=20;
            break;
        case 3:
            price=30;
            break;
        default:
            cout<<"Invalid choice";
            return 0;
    }

    cout<<"Enter units="<<endl;
    cin>>units;

    if(units<=0)
    {
        cout<<"Invalid units";
    }
    else
    {
        bill=units*price;

        if(units>200)
            discount=bill*10/100;
        else
            discount=0;

        bill=bill-discount;
        tax=bill*5/100;
        final_bill=bill+tax;

        cout<<"Discount="<<discount<<endl;
        cout<<"Tax="<<tax<<endl;
        cout<<"Final bill="<<final_bill;
    }

    return 0;
}