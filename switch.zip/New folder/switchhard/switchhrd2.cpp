//2. Hotel Room Booking
//Question: Display a menu with Standard (Rs. 3000/day), Deluxe (Rs. 5000/day), and Suite (Rs. 8000/day). Take room choice and number of days. Give a 15% discount if the booking is for 5 or more days. Display the original bill, discount, and final bill.
//Solution
#include<iostream>
using namespace std;

int main()
{
    int choice, days, price;
    float bill, discount, final_bill;

    cout<<"1. Standard"<<endl;
    cout<<"2. Deluxe"<<endl;
    cout<<"3. Suite"<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            price=3000;
            break;
        case 2:
            price=5000;
            break;
        case 3:
            price=8000;
            break;
        default:
            cout<<"Invalid choice";
            return 0;
    }

    cout<<"Enter number of days="<<endl;
    cin>>days;

    if(days<=0)
    {
        cout<<"Invalid days";
    }
    else
    {
        bill=price*days;

        if(days>=5)
            discount=bill*15/100;
        else
            discount=0;

        final_bill=bill-discount;

        cout<<"Original bill="<<bill<<endl;
        cout<<"Discount="<<discount<<endl;
        cout<<"Final bill="<<final_bill;
    }

    return 0;
}