//2. Shopping Mall Billing System
//Question: Write a C++ program that displays a menu:
//- 1. Laptop — Rs. 100000
//- 2. Mobile — Rs. 50000
//- 3. Headphones — Rs. 5000
//- 4. Exit
//Take the product choice and quantity as input. Apply these rules:
//- Quantity must be greater than zero.
//- If quantity is 5 or more, give a 20% discount.
//- If quantity is 3 or 4, give a 10% discount.
//- Otherwise, no discount.
//- Add 8% tax after deducting the discount.
//- Display the original bill, discount, tax, and final bill.
#include<iostream>
using namespace std;

int main()
{
    int choice, quantity, price;
    float bill, discount, tax, final_bill;

    cout<<"1. Laptop"<<endl;
    cout<<"2. Mobile"<<endl;
    cout<<"3. Headphones"<<endl;
    cout<<"4. Exit"<<endl;

    cout<<"Enter choice="<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            cout<<"Enter quantity="<<endl;
            cin>>quantity;

            if(quantity<=0)
            {
                cout<<"Invalid quantity";
            }
            else
            {
                price=100000;
                bill=price*quantity;

                if(quantity>=5)
                    discount=bill*20/100;
                else if(quantity>=3)
                    discount=bill*10/100;
                else
                    discount=0;

                bill=bill-discount;
                tax=bill*8/100;
                final_bill=bill+tax;

                cout<<"Original bill="<<price*quantity<<endl;
                cout<<"Discount="<<discount<<endl;
                cout<<"Tax="<<tax<<endl;
                cout<<"Final bill="<<final_bill;
            }
            break;

        case 2:
            cout<<"Enter quantity="<<endl;
            cin>>quantity;

            if(quantity<=0)
            {
                cout<<"Invalid quantity";
            }
            else
            {
                price=50000;
                bill=price*quantity;

                if(quantity>=5)
                    discount=bill*20/100;
                else if(quantity>=3)
                    discount=bill*10/100;
                else
                    discount=0;

                bill=bill-discount;
                tax=bill*8/100;
                final_bill=bill+tax;

                cout<<"Original bill="<<price*quantity<<endl;
                cout<<"Discount="<<discount<<endl;
                cout<<"Tax="<<tax<<endl;
                cout<<"Final bill="<<final_bill;
            }
            break;

        case 3:
            cout<<"Enter quantity="<<endl;
            cin>>quantity;

            if(quantity<=0)
            {
                cout<<"Invalid quantity";
            }
            else
            {
                price=5000;
                bill=price*quantity;

                if(quantity>=5)
                    discount=bill*20/100;
                else if(quantity>=3)
                    discount=bill*10/100;
                else
                    discount=0;

                bill=bill-discount;
                tax=bill*8/100;
                final_bill=bill+tax;

                cout<<"Original bill="<<price*quantity<<endl;
                cout<<"Discount="<<discount<<endl;
                cout<<"Tax="<<tax<<endl;
                cout<<"Final bill="<<final_bill;
            }
            break;

        case 4:
            cout<<"Program ended";
            break;

        default:
            cout<<"Invalid choice";
    }

    return 0;
}