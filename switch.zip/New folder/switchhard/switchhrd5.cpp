#include<iostream>
using namespace std;

int main()
{
    int choice, hours, price;
    float bill, discount;

    cout<<"1. Bike"<<endl;
    cout<<"2. Car"<<endl;
    cout<<"3. Bus"<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
            price=50;
            break;

        case 2:
            price=100;
            break;

        case 3:
            price=200;
            break;

        default:
            cout<<"Invalid choice";
            return 0;
    }

    cout<<"Enter parking hours="<<endl;
    cin>>hours;

    if(hours<=0)
        cout<<"Invalid hours";
    else
    {
        bill=price*hours;

        if(hours>5)
            discount=bill*10/100;
        else
            discount=0;

        bill=bill-discount;

        cout<<"Final parking fee="<<bill;
    }

    return 0;
}